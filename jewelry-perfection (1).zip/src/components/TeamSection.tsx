import { TeamMember } from "../types";
import { Users, Layers, Sparkles, Check } from "lucide-react";

interface TeamSectionProps {
  team: TeamMember[];
}

export default function TeamSection({ team }: TeamSectionProps) {
  const departments = [
    {
      name: "Clipping Paths & Background Isolation",
      count: "8 Specialists",
      focus: "Perfect Pen-tool clipping paths, edge softening, transparent masking, set alignments."
    },
    {
      name: "Metal Polishing & Refraction Control",
      count: "6 Specialists",
      focus: "Scratch elimination, glare reduction, yellow gold / rose gold alloy color balancing."
    },
    {
      name: "Diamond Sparkle & Facet Calibration",
      count: "6 Specialists",
      focus: "Fire amplification, facet mask contrast adjustments, Solitaire solitaire tuning, prong correction."
    },
    {
      name: "Colored Gemstones & Hue Matching",
      count: "5 Specialists",
      focus: "Clarity refinement, emerald/ruby hue matching, saturation preservation, luster boosting."
    }
  ];

  return (
    <section id="team" className="py-24 bg-[#080808] relative overflow-hidden border-t border-white/10">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#D4AF37] opacity-[0.015] rounded-full blur-[120px] -mr-30 -mt-30 pointer-events-none z-0"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16" id="team-header">
          <div className="inline-flex items-center gap-3 text-[#D4AF37] text-xs font-bold tracking-[0.3em] uppercase mb-4">
            <span className="w-12 h-[1px] bg-[#D4AF37]"></span>
            The Specialists
            <span className="w-12 h-[1px] bg-[#D4AF37]"></span>
          </div>
          <h2 className="font-display font-light text-3xl sm:text-5xl text-white mb-4">
            Meet the Experts Behind <span className="italic font-serif text-[#D4AF37]">Jewelry Perfection</span>
          </h2>
          <p className="font-sans text-gray-400 text-sm sm:text-base font-light leading-relaxed">
            Our 25 highly trained jewelry retouchers operate in structured departments under strict quality guidelines to guarantee consistency across thousands of images.
          </p>
        </div>

        {/* Core Leaders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-20" id="team-leaders-grid">
          {team.map((member) => (
            <div 
              key={member.id}
              className="bg-[#080808] border border-white/10 rounded-none overflow-hidden group transition-all duration-300 hover:border-[#D4AF37]/40 shadow-xl"
              id={`team-member-${member.id}`}
            >
              {/* Member Image */}
              <div className="aspect-[4/5] bg-[#121212] relative overflow-hidden">
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60" />
                
                {/* Core label */}
                {member.isCore && (
                  <span className="absolute top-4 right-4 text-[9px] font-mono tracking-widest uppercase text-[#D4AF37] px-2.5 py-1 rounded-none bg-black/85 border border-[#D4AF37]/35">
                    Senior Director
                  </span>
                )}
              </div>

              {/* Member Details */}
              <div className="p-6 text-left">
                <h4 className="font-display text-base font-semibold text-white group-hover:text-[#D4AF37] transition-colors">
                  {member.name}
                </h4>
                <p className="font-sans text-xs text-gray-500 font-light mt-0.5">
                  {member.role}
                </p>

                {/* Micro Expertise Tags */}
                <div className="mt-4 space-y-1.5 border-t border-white/10 pt-4">
                  {member.expertise.map((exp, expIdx) => (
                    <div key={expIdx} className="flex items-center gap-1.5 text-[11px] text-gray-400 font-sans font-light">
                      <span className="text-[#D4AF37] text-[9px]">✦</span>
                      <span>{exp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* 25 Specialists Department Structure Matrix */}
        <div className="bg-[#080808] border border-white/10 p-8 sm:p-12 rounded-none text-left shadow-2xl" id="team-department-matrix">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column (Info) */}
            <div className="lg:col-span-4 flex flex-col gap-4">
              <div className="w-12 h-12 rounded-none border border-white/10 bg-white/5 flex items-center justify-center text-[#D4AF37]">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-display text-xl font-semibold text-white">
                Our 25 Specialists Organization Matrix
              </h3>
              <p className="font-sans text-xs sm:text-sm text-gray-400 font-light leading-relaxed">
                To guarantee lightning-fast delivery of large bulk volumes without dropping quality, our agency operates in rotating shifts. Each specialist focuses strictly on their departmental expertise.
              </p>
              
              <div className="space-y-2 mt-4">
                <div className="flex items-center gap-2.5 text-xs text-gray-400 font-sans font-light">
                  <Check className="text-[#D4AF37] w-4 h-4" />
                  <span>24/7 Continuous Shift Coverage</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-gray-400 font-sans font-light">
                  <Check className="text-[#D4AF37] w-4 h-4" />
                  <span>Strict Magnification QC Filters</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs text-gray-400 font-sans font-light">
                  <Check className="text-[#D4AF37] w-4 h-4" />
                  <span>Dedicated Secure Servers (NDAs)</span>
                </div>
              </div>
            </div>

            {/* Right Column (Department Cards) */}
            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6" id="matrix-departments">
              {departments.map((dept, index) => (
                <div key={index} className="p-6 bg-[#080808] border border-white/10 rounded-none relative overflow-hidden group hover:border-[#D4AF37]/40 transition-all">
                  <span className="font-mono text-[9px] tracking-widest text-[#D4AF37] bg-[#D4AF37]/5 px-2.5 py-1 border border-[#D4AF37]/20 rounded-none absolute top-4 right-4">
                    {dept.count}
                  </span>
                  
                  <h4 className="font-display text-sm font-semibold text-white mb-2 group-hover:text-[#D4AF37] transition-colors pr-16">
                    {dept.name}
                  </h4>
                  <p className="font-sans text-xs text-gray-500 leading-relaxed font-light">
                    {dept.focus}
                  </p>
                </div>
              ))}
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
