import express from "express";
import path from "path";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "db.json");
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads");

// Initialize Gemini Client
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    })
  : null;

// Ensure directories exist
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Default Seed Data
const defaultData = {
  services: [
    {
      id: "srv-1",
      title: "High-End Jewelry Retouching",
      description: "Complete luxury makeover for your fine jewelry images. Includes high-fidelity polishing, diamond sparkle restoration, and flawless alignment.",
      benefits: ["Intricate surface cleanup", "Prong and setting realignment", "True-to-life color fidelity", "Flawless mirror-finish metal shine"],
      iconName: "Sparkles",
      price: "From $3.50 / image"
    },
    {
      id: "srv-2",
      title: "Background Removal & Pure White",
      description: "Exquisite isolation of jewelry items onto pure 100% white, solid black, or transparent backgrounds suitable for high-end commerce.",
      benefits: ["Perfect hand-drawn clipping paths", "Smooth edge transitions", "Studio-standard Amazon/Shopify/Etsy compliance", "Custom textured background options"],
      iconName: "Scissors",
      price: "From $1.50 / image"
    },
    {
      id: "srv-3",
      title: "Diamond & Gemstone Enhancement",
      description: "Unlock the natural fire, brilliance, and facets of diamonds and precious gemstones. We correct clarity, color, and reflection profiles.",
      benefits: ["Brilliance and fire amplification", "Gemstone depth and facet restoration", "Color tint correction (Emerald, Sapphire, Ruby)", "Prong shadow cleaning"],
      iconName: "Gem",
      price: "From $2.50 / image"
    },
    {
      id: "srv-4",
      title: "Metal Polishing & Texture Correction",
      description: "Remove micro-scratches, dust, and photographer reflections. We restore gold, silver, rose gold, and platinum to mirror perfection.",
      benefits: ["Scratch and dust elimination", "Metal gradient smoothing", "Authentic metallic luster preservation", "Satin/brushed metal restoration"],
      iconName: "Zap",
      price: "From $2.00 / image"
    },
    {
      id: "srv-5",
      title: "Reflection & Shadow Control",
      description: "Add soft, organic ground reflections and drop shadows to give your jewelry weight, realism, and a premium studio feel.",
      benefits: ["Realistic ground drop shadows", "Luxury mirror reflection effects", "Natural light source alignment", "Floating jewelry dimension control"],
      iconName: "Sun",
      price: "From $1.80 / image"
    },
    {
      id: "srv-6",
      title: "Color Correction & Metal Matching",
      description: "Ensure color accuracy of precious stones and metal alloys. We can shift metals between Yellow Gold, White Gold, and Rose Gold.",
      benefits: ["Pantone and real-metal color matching", "Multi-metal alloy separation", "Consistent gemstone saturation across collections", "Non-destructive color grading"],
      iconName: "Paintbrush",
      price: "From $1.50 / image"
    }
  ],
  beforeAfter: [
    {
      id: "ba-1",
      title: "Royal Diamond Solitaire Ring",
      description: "Complete metal repolishing and diamond fire enhancement. Removed harsh yellow camera reflections and placed on luxury shadow gradient.",
      category: "Jewelry Retouching",
      beforeUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&auto=format&fit=crop",
      afterUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800&auto=format&fit=crop",
      servicesApplied: ["Diamond Fire Amplification", "Platinum Polishing", "Prong Realignment", "Organic Shadow"],
      presetFilter: "preset-ring"
    },
    {
      id: "ba-2",
      title: "Emerald & Gold Pendant",
      description: "Polished 24K yellow gold and removed camera reflections. Enhanced emerald clarity and restored natural stone facets and depth.",
      category: "Gemstone Enhancement",
      beforeUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&auto=format&fit=crop",
      afterUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800&auto=format&fit=crop",
      servicesApplied: ["Gemstone Clarity Correction", "24K Gold Polish", "Studio Background Removal", "Reflection Control"],
      presetFilter: "preset-emerald"
    },
    {
      id: "ba-3",
      title: "Premium Rose Gold Chronograph",
      description: "Intricate bezel polishing, crystal glass scratch removal, and brushed metal texture restoration. Balanced all dials and hands.",
      category: "Luxury Retouching",
      beforeUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop",
      afterUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop",
      servicesApplied: ["Glass Scratch Elimination", "Rose Gold Polishing", "Dial Contrast Balancing", "Floating Mirror Shadow"],
      presetFilter: "preset-watch"
    }
  ],
  gallery: [
    {
      id: "gal-1",
      title: "Golden Filigree Diamond Bracelet",
      category: "Jewelry Retouching",
      imageUrl: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800&auto=format&fit=crop",
      description: "High-end hand-polished details with diamond fire correction."
    },
    {
      id: "gal-2",
      title: "Solitaire Sapphire Ring",
      category: "Diamond Enhancement",
      imageUrl: "https://images.unsplash.com/photo-1617038260897-41a1f14a8ca0?w=800&auto=format&fit=crop",
      description: "Enhanced deep sapphire crystal facets and pristine platinum shine."
    },
    {
      id: "gal-3",
      title: "Art Deco Emerald Earrings",
      category: "Luxury Retouching",
      imageUrl: "https://images.unsplash.com/photo-1635767798638-3e25273a8236?w=800&auto=format&fit=crop",
      description: "Reflection control and prong alignment for catalog standards."
    },
    {
      id: "gal-4",
      title: "Minimalist Diamond Bands",
      category: "Background Removal",
      imageUrl: "https://images.unsplash.com/photo-1603561591411-07134e71a2a9?w=800&auto=format&fit=crop",
      description: "Clean isolation onto pure black background for high-end magazine display."
    },
    {
      id: "gal-5",
      title: "Fine Gold Wedding Set",
      category: "Color Correction",
      imageUrl: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=800&auto=format&fit=crop",
      description: "Polishing and gold tone matching for consistent collection presentation."
    },
    {
      id: "gal-6",
      title: "Classic Silver Charm Bracelet",
      category: "Product Editing",
      imageUrl: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=800&auto=format&fit=crop",
      description: "Complex shadow creation and white-metal scratch removal."
    }
  ],
  team: [
    {
      id: "tm-1",
      name: "M.R Mahatab",
      role: "Founder & Creative Director",
      imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop",
      expertise: ["Quality Control", "Art Direction", "Workflow Automation", "Client Relations"],
      isCore: true
    },
    {
      id: "tm-2",
      name: "Ismail Al Yafi",
      role: "Senior Retouching Specialist",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop",
      expertise: ["High-End Metal Polishing", "Diamond Contrast Adjustments", "Complex Clipping Paths"],
      isCore: true
    },
    {
      id: "tm-3",
      name: "Amina Rahman",
      role: "Lead Gemstone Enhancer",
      imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop",
      expertise: ["Gemstone Facet Detailing", "Color Precision Matching", "E-commerce Standards"],
      isCore: false
    },
    {
      id: "tm-4",
      name: "Tanvir Hasan",
      role: "Bulk Project Coordinator",
      imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=500&auto=format&fit=crop",
      expertise: ["High Volume Handling", "Timeline Management", "File Structure Organization"],
      isCore: false
    }
  ],
  testimonials: [
    {
      id: "t-1",
      name: "Sarah Jenkins",
      company: "Director of Operations at Aura Fine Jewelry (New York)",
      review: "Jewelry Perfection has completely transformed our e-commerce catalog. Over 5,000 images processed and every single one is absolute perfection. Their speed and precision are world-class.",
      rating: 5,
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop"
    },
    {
      id: "t-2",
      name: "Marcus Valerius",
      company: "Founder of Valerius Luxury (London)",
      review: "Their diamond and gemstone enhancement techniques are sheer magic. Our e-commerce sales conversion rate improved by 35% after we updated our store with their edited high-end renders.",
      rating: 5,
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop"
    },
    {
      id: "t-3",
      name: "Kenji Takahashi",
      company: "Commercial Photographer (Tokyo)",
      review: "As a professional jewelry photographer, I'm extremely picky. The team at Jewelry Perfection matches my specifications perfectly. Metal polishing, scratch removal, and shadows look 100% natural.",
      rating: 5,
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop"
    }
  ],
  contacts: [] as any[],
  sampleRequests: [] as any[],
  settings: {
    phone: "+880 1328-252376",
    email: "info.jewelryperfection@gmail.com",
    facebook: "https://www.facebook.com/JewelryPerfection",
    instagram: "https://www.instagram.com/_jewelryperfection/",
    behance: "https://www.behance.net/JewelryPerfection",
    fiverr: "https://www.fiverr.com/sellers/ismailalyafi",
    address: "Dhaka, Bangladesh",
    businessHours: "24/7 Client Support",
    responseTime: "Within 30 Minutes",
    metaTitle: "Premium Jewelry Retouching Services | Jewelry Perfection",
    metaDescription: "Professional high-end jewelry photo retouching and e-commerce product image editing agency. Serving luxury jewelry brands, retailers, and photographers worldwide."
  }
};

// Database utility
const getDB = () => {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultData, null, 2));
    return defaultData;
  }
  try {
    const data = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Failed to parse db.json, returning default data", error);
    return defaultData;
  }
};

const saveDB = (data: any) => {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
};

// Express Middlewares
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Serve static uploads
app.use("/uploads", express.static(UPLOADS_DIR));

// Initial consolidated application data endpoint
app.get("/api/init", (req, res) => {
  try {
    const db = getDB();
    res.json({
      services: db.services || [],
      beforeAfter: db.beforeAfter || [],
      gallery: db.gallery || [],
      team: db.team || [],
      testimonials: db.testimonials || [],
      settings: db.settings || null
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Admin authentication endpoint
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "M.R Mahatab" && password === "mahatab") {
    res.json({ success: true, user: { name: "M.R Mahatab", role: "Administrator" } });
  } else {
    res.status(401).json({ success: false, message: "Invalid username or password" });
  }
});

// Settings Endpoints
app.get("/api/settings", (req, res) => {
  const db = getDB();
  res.json(db.settings);
});

app.put("/api/settings", (req, res) => {
  const db = getDB();
  db.settings = { ...db.settings, ...req.body };
  saveDB(db);
  res.json({ success: true, settings: db.settings });
});

// Services Endpoints
app.get("/api/services", (req, res) => {
  const db = getDB();
  res.json(db.services);
});

app.post("/api/services", (req, res) => {
  const db = getDB();
  const newService = { id: `srv-${Date.now()}`, ...req.body };
  db.services.push(newService);
  saveDB(db);
  res.json({ success: true, service: newService });
});

app.put("/api/services/:id", (req, res) => {
  const db = getDB();
  const index = db.services.findIndex((s: any) => s.id === req.params.id);
  if (index !== -1) {
    db.services[index] = { ...db.services[index], ...req.body };
    saveDB(db);
    res.json({ success: true, service: db.services[index] });
  } else {
    res.status(404).json({ success: false, message: "Service not found" });
  }
});

app.delete("/api/services/:id", (req, res) => {
  const db = getDB();
  db.services = db.services.filter((s: any) => s.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// BeforeAfter Endpoints
app.get("/api/beforeafter", (req, res) => {
  const db = getDB();
  res.json(db.beforeAfter);
});

app.post("/api/beforeafter", (req, res) => {
  const db = getDB();
  const newProject = { id: `ba-${Date.now()}`, ...req.body };
  db.beforeAfter.push(newProject);
  saveDB(db);
  res.json({ success: true, project: newProject });
});

app.put("/api/beforeafter/:id", (req, res) => {
  const db = getDB();
  const index = db.beforeAfter.findIndex((b: any) => b.id === req.params.id);
  if (index !== -1) {
    db.beforeAfter[index] = { ...db.beforeAfter[index], ...req.body };
    saveDB(db);
    res.json({ success: true, project: db.beforeAfter[index] });
  } else {
    res.status(404).json({ success: false, message: "Project not found" });
  }
});

app.delete("/api/beforeafter/:id", (req, res) => {
  const db = getDB();
  db.beforeAfter = db.beforeAfter.filter((b: any) => b.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// Gallery Endpoints
app.get("/api/gallery", (req, res) => {
  const db = getDB();
  res.json(db.gallery);
});

app.post("/api/gallery", (req, res) => {
  const db = getDB();
  const newItem = { id: `gal-${Date.now()}`, ...req.body };
  db.gallery.push(newItem);
  saveDB(db);
  res.json({ success: true, item: newItem });
});

app.delete("/api/gallery/:id", (req, res) => {
  const db = getDB();
  db.gallery = db.gallery.filter((g: any) => g.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// Team Endpoints
app.get("/api/team", (req, res) => {
  const db = getDB();
  res.json(db.team);
});

app.post("/api/team", (req, res) => {
  const db = getDB();
  const newMember = { id: `tm-${Date.now()}`, ...req.body };
  db.team.push(newMember);
  saveDB(db);
  res.json({ success: true, member: newMember });
});

app.delete("/api/team/:id", (req, res) => {
  const db = getDB();
  db.team = db.team.filter((t: any) => t.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// Testimonials Endpoints
app.get("/api/testimonials", (req, res) => {
  const db = getDB();
  res.json(db.testimonials);
});

app.post("/api/testimonials", (req, res) => {
  const db = getDB();
  const newReview = { id: `t-${Date.now()}`, ...req.body };
  db.testimonials.push(newReview);
  saveDB(db);
  res.json({ success: true, testimonial: newReview });
});

app.delete("/api/testimonials/:id", (req, res) => {
  const db = getDB();
  db.testimonials = db.testimonials.filter((t: any) => t.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// Contacts Endpoints (Contact form submission and inquiries)
app.get("/api/contacts", (req, res) => {
  const db = getDB();
  res.json(db.contacts || []);
});

app.post("/api/contacts", (req, res) => {
  const db = getDB();
  const newContact = {
    id: `cnt-${Date.now()}`,
    ...req.body,
    date: new Date().toISOString()
  };
  if (!db.contacts) db.contacts = [];
  db.contacts.push(newContact);
  saveDB(db);
  res.json({ success: true, contact: newContact });
});

app.delete("/api/contacts/:id", (req, res) => {
  const db = getDB();
  if (db.contacts) {
    db.contacts = db.contacts.filter((c: any) => c.id !== req.params.id);
    saveDB(db);
  }
  res.json({ success: true });
});

// Free Sample Edit Request Endpoints
app.get("/api/samples", (req, res) => {
  const db = getDB();
  res.json(db.sampleRequests || []);
});

app.post("/api/samples", (req, res) => {
  const db = getDB();
  const newRequest = {
    id: `smp-${Date.now()}`,
    ...req.body,
    status: "Pending",
    date: new Date().toISOString()
  };
  if (!db.sampleRequests) db.sampleRequests = [];
  db.sampleRequests.push(newRequest);
  saveDB(db);
  res.json({ success: true, sampleRequest: newRequest });
});

app.put("/api/samples/:id", (req, res) => {
  const db = getDB();
  const index = db.sampleRequests.findIndex((s: any) => s.id === req.params.id);
  if (index !== -1) {
    db.sampleRequests[index] = { ...db.sampleRequests[index], ...req.body };
    saveDB(db);
    res.json({ success: true, sampleRequest: db.sampleRequests[index] });
  } else {
    res.status(404).json({ success: false, message: "Sample request not found" });
  }
});

app.delete("/api/samples/:id", (req, res) => {
  const db = getDB();
  if (db.sampleRequests) {
    db.sampleRequests = db.sampleRequests.filter((s: any) => s.id !== req.params.id);
    saveDB(db);
  }
  res.json({ success: true });
});

// Base64 file upload endpoint
app.post("/api/upload", (req, res) => {
  const { name, data } = req.body;
  if (!name || !data) {
    return res.status(400).json({ success: false, message: "Missing file name or file data" });
  }

  try {
    const fileExtension = path.extname(name) || ".png";
    const base64Data = data.replace(/^data:image\/\w+;base64,/, "");
    const buffer = Buffer.from(base64Data, "base64");
    const uniqueName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${fileExtension}`;
    const filePath = path.join(UPLOADS_DIR, uniqueName);

    fs.writeFileSync(filePath, buffer);
    res.json({ success: true, url: `/uploads/${uniqueName}` });
  } catch (error: any) {
    console.error("File upload failed", error);
    res.status(500).json({ success: false, message: "File upload failed", error: error.message });
  }
});

// AI Jewelry Retouching Suggestion endpoint (using Gemini API)
app.post("/api/gemini/analyze", async (req, res) => {
  if (!ai) {
    return res.status(503).json({
      success: false,
      message: "AI diagnostics are currently offline. Please configure a valid GEMINI_API_KEY in the Secrets panel."
    });
  }

  const { imageBase64 } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ success: false, message: "Missing image base64 data" });
  }

  try {
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: "image/png",
            data: cleanBase64,
          },
        },
        "You are Jewelry Perfection's master AI QC and retouching strategist. Analyze this jewelry photo in detail. " +
        "Provide a professional, luxury retouching analysis that outlines " +
        "what retouching is required to make this image retail-ready for luxury e-commerce brands (such as Tiffany or Cartier). " +
        "Format your answer cleanly into exactly 4 logical sections: " +
        "1. Metal surface & reflections, " +
        "2. Diamond/Gemstone facet sparkle & clarity, " +
        "3. Background cleanup & clipping paths, " +
        "4. Lighting & ground shadow simulation. " +
        "Keep the tone extremely elite, premium, technical, and trust-inspiring."
      ],
    });

    res.json({ success: true, analysis: response.text });
  } catch (error: any) {
    console.error("Gemini analysis failed", error);
    res.status(500).json({ success: false, message: "AI analysis failed", error: error.message });
  }
});

// Main server start routine
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development mode with Vite middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production mode serving compiled files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Luxury Agency Server running on http://localhost:${PORT}`);
  });
}

startServer();
